#include <iostream>
#include <fstream>
#include <sys/stat.h>
#include <magic.h>
#include <cryptopp/cryptlib.h>
#include <cryptopp/sha.h>
#include <cryptopp/hex.h>
#include <Python.h>

// Function to compute the SHA-256 hash of a file
std::string computeSHA256Hash(const std::string& file_path) {
    CryptoPP::SHA256 hash;
    std::string hashValue;

    // Open the file in binary mode
    std::ifstream file(file_path, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << file_path << std::endl;
        return "";
    }

    // Read the file in chunks and hash it
    char buffer[1024];
    int bytesRead;
    while (file.read(buffer, sizeof(buffer))) {
        bytesRead = file.gcount();  // Get the actual number of bytes read
        hash.Update(reinterpret_cast<const CryptoPP::byte*>(buffer), bytesRead);
    }

    // Finalize the hash and convert it to a string
    CryptoPP::byte digest[CryptoPP::SHA256::DIGESTSIZE];
    hash.Final(digest);

    CryptoPP::HexEncoder encoder(new CryptoPP::StringSink(hashValue));
    encoder.Put(digest, sizeof(digest));
    encoder.MessageEnd();

    return hashValue;
}

// Function to create a text image
void createTextImage(const std::string& file_path) {
    // Initialize the Python interpreter
    Py_Initialize();

    // Check if Python is initialized successfully
    if (Py_IsInitialized()) {
        // Execute the Python script and pass the file path
        std::string command = "import sys\n"
                              "sys.argv = ['', '" + file_path + "']\n"
                              "exec(compile(open('text_image.py').read(), 'text_image.py', 'exec'))\n";
        PyRun_SimpleString(command.c_str());

        // Check if the Python script executed successfully
        if (!PyErr_Occurred()) {
            std::cout << "Text image generated successfully." << std::endl;
        } else {
            std::cerr << "Error generating text image." << std::endl;
            PyErr_Print();
        }

        // Finalize the Python interpreter
        Py_Finalize();
    } else {
        std::cerr << "Error initializing Python interpreter." << std::endl;
    }
}

int main() {
    std::string file_path;

    // Step 1: Accept the file path as input
    std::cout << "Enter the file path: ";
    std::cin >> file_path;

    // Step 2: Use the stat function to retrieve file attributes
    struct stat file_stats;
    if (stat(file_path.c_str(), &file_stats) == 0) {
        std::cout << "File: " << file_path << std::endl;
        std::cout << "Size: " << file_stats.st_size << " bytes" << std::endl;
        std::cout << "Mode: " << std::oct << file_stats.st_mode << std::dec << std::endl;

        // Check if it's a regular file
        if (S_ISREG(file_stats.st_mode)) {
            // Proceed with the following steps

            // Step 3: Initialize the libmagic library
            magic_t cookie;
            cookie = magic_open(MAGIC_MIME_TYPE);
            if (cookie == NULL) {
                std::cerr << "Error initializing libmagic." << std::endl;
                return 1;
            }

            if (magic_load(cookie, NULL) == 0) {
                // Step 4: Identify the file type
                const char* file_type = magic_file(cookie, file_path.c_str());
                if (file_type) {
                    std::cout << "Type: " << file_type << std::endl;
                } else {
                    std::cerr << "Error identifying file type." << std::endl;
                    magic_close(cookie);
                    return 1;
                }
            } else {
                std::cerr << "Error loading magic database." << std::endl;
                magic_close(cookie);
                return 1;
            }

           // Step 5: Compute and display the SHA-256 hash
              std::string sha256Hash = computeSHA256Hash(file_path);
              if (!sha256Hash.empty()) {
              std::cout << "SHA-256 Hash: " << sha256Hash << std::endl;
           }

            /// Step 6: Generate a text image
                createTextImage(sha256Hash, file_path);

            // Step 7: Clean up and release resources
            magic_close(cookie);

            // Step 8: End the program
            return 0;
        } else if (S_ISDIR(file_stats.st_mode)) {
            std::cerr << "Error: Input is a directory. Directories are not supported." << std::endl;
            return 1;
        } else {
            std::cerr << "Error: Unsupported file type." << std::endl;
            return 1;
        }
    } else {
        std::cerr << "Error accessing file attributes." << std::endl;
        return 1;
    }
}

