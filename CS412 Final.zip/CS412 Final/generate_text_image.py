import sys
import subprocess

def generate_text_image(file_path):
    # Call your text_image.py script with the file path
    subprocess.run(["python3", "text_image.py", file_path])

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 generate_text_image.py /path/to/infected.txt")
        sys.exit(1)

    file_path = sys.argv[1]
    generate_text_image(file_path)

