import sys
import hashlib
from PIL import Image, ImageDraw, ImageFont

# Function to create a text image with the given text
def create_text_image(text, image_path):
    # Define image size and background color
    image_width = 400
    image_height = 100
    background_color = (255, 255, 255)

    # Create a new image with a white background
    image = Image.new("RGB", (image_width, image_height), background_color)
    draw = ImageDraw.Draw(image)

    # Load a font (replace 'font_path' with the actual path to your font file)
    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    font = ImageFont.truetype(font_path, 24)

    # Define the position and text color
    text_position = (10, 40)
    text_color = (0, 0, 0)

    # Draw the text on the image
    draw.text(text_position, text, fill=text_color, font=font)

    # Save the image to the specified path
    image.save(image_path)

# Function to calculate the SHA-256 hash of a file
def calculate_sha256(file_path):
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        while True:
            data = f.read(65536)  # Read in 64k chunks
            if not data:
                break
            sha256_hash.update(data)
    return sha256_hash.hexdigest()

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <file_path>")
        sys.exit(1)

    file_path = sys.argv[1]

# Calculate the SHA-256 hash of the file
sha256_hash = calculate_sha256(file_path)

# Specify the output image path
output_image_path = "text_image.png"

# Create the text image with the calculated SHA-256 hash
create_text_image(sha256_hash, output_image_path)

print("Text image generated successfully at:", output_image_path)

