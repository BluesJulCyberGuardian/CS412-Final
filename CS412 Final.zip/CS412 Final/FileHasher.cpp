#include <iostream>
#include <fstream>
#include <vector>
#include <thread>
#include <mutex>
#include <filesystem>  // Include the filesystem header
#include <cryptopp/sha.h>  // Include the Crypto++ SHA header

using namespace std;

// A struct to represent a file to be hashed.
struct FileToHash {
  string path;
  string hash;
};

// A mutex to protect the shared report.
mutex reportMutex;

// A vector to store the report.
vector<FileToHash> report;

// A function to hash a file.
void hashFile(FileToHash& fileToHash) {
  // Create a SHA-256 hash object.
  CryptoPP::SHA256 hash;

  // Open the file in binary mode.
  ifstream file(fileToHash.path, ios::binary);

  // Read the file in chunks and hash it.
  char buffer[1024];
  int bytesRead;
  while ((bytesRead = file.read(buffer, sizeof(buffer)).gcount())) {
    hash.Update(reinterpret_cast<CryptoPP::byte*>(buffer), bytesRead);
  }

  // Close the file.
  file.close();

  // Finalize the hash and convert it to a string.
  CryptoPP::byte digest[CryptoPP::SHA256::DIGESTSIZE];
  hash.Final(digest);
  CryptoPP::HexEncoder encoder;
  string hashString;
  encoder.Attach(new CryptoPP::StringSink(hashString));
  encoder.Put(digest, sizeof(digest));
  encoder.MessageEnd();

  // Lock the mutex to protect the shared report.
  lock_guard<mutex> lock(reportMutex);

  // Add the file and its hash to the report.
  report.push_back({fileToHash.path, hashString});
}

// A function to print the report to the standard output.
void printReport() {
  lock_guard<mutex> lock(reportMutex);

  for (const FileToHash& fileToHash : report) {
    cout << fileToHash.path << ": " << fileToHash.hash << endl;
  }
}

int main(int argc, char** argv) {
  // Check the command line arguments.
  if (argc != 3) {
    cout << "Usage: FileHasher <directory> <hash algorithm>" << endl;
    return 1;
  }

  // Get the directory from the command line argument.
  string directory = argv[1;

  // Create a vector to store the threads.
  vector<thread> threads;

  // Iterate over the files in the directory and start a thread to hash each file.
  for (const auto& entry : filesystem::directory_iterator(directory)) {
    // If the entry is a regular file, add it to the vector of files to hash.
    if (entry.is_regular_file()) {
      threads.push_back(thread(hashFile, FileToHash{entry.path(), ""}));
    }
  }

  // Wait for all the threads to finish.
  for (thread& thread : threads) {
    thread.join();
  }

  // Print the report.
  printReport();

  return 0;
}

